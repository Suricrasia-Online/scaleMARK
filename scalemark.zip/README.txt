### scaleMARK - blackle / Suricrasia Online ###

scaleMARK is a 4k into for 64-bit linux, specifically targeting Ubuntu 18.10

Packages needed (all of these are installed by default except for sdl2):

libsdl2-2.0-0
libspectre1
libopus0
and whatever package gives you libgl (depends on graphics card)

Four versions of the demo are distributed. Two are just unpacked versions of the first two, and end with "_unpacked"

scalemark : 1920x1080 fullscreen, 4spp
scalemark_small : 640x360 windowed, 1spp

If you have a low end machine, try scalemark_small first. My graphics card sucks so I had to develop it in that resolution haha.
